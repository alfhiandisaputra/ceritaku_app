// Dummy reportMapper, bisa disesuaikan jika ada kebutuhan mapping data
export const reportMapper = async (report) => report;
